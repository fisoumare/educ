<?php

header('Location:public/');