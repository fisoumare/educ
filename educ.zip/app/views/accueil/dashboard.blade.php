@extends('tpl')

@section('content')
<h1>Tableau de bord</h1>

@stop

