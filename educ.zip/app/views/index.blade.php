@extends('tpl')

@section('content')
    @include('menu_bar')
	<div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>Test Laravel</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <?php echo nl2br('Cursus urna elit purus scelerisque mauris pid ut ut arcu enim, dis etiam et sit quis turpis magna pulvinar mattis? Auctor tortor porta placerat, a vut, nec nunc? Hac dis. Scelerisque arcu, dolor, ut dignissim! Urna, tincidunt risus. Odio! Magnis, vel diam. Eros vel cum scelerisque ultrices quis, pellentesque nec, adipiscing dictumst ridiculus odio cum, placerat facilisis, sit tempor tristique? Nec etiam placerat nisi, ac urna elementum tempor sit aenean, non enim ut aliquam porttitor mid pid cum ut natoque? Porta parturient? Porttitor elit rhoncus a scelerisque vel, risus lorem pulvinar scelerisque. Ac nunc mus, enim velit phasellus rhoncus ac, aliquam aenean, adipiscing turpis! Cursus etiam tempor nascetur elementum tincidunt platea sociis! Turpis dignissim dapibus, amet placerat tincidunt, risus aliquet.

        Nisi? Integer penatibus cursus lectus parturient lundium, nascetur cursus. Natoque et? Sed adipiscing, ultricies nisi mauris vel, mus ultrices? Nisi urna risus sit, cursus egestas placerat urna? Cum turpis. Eu ultricies, quis tristique porta nascetur lundium odio dolor ut, sed eros scelerisque penatibus dignissim! Eros dolor augue! Montes eros elementum tincidunt, placerat ultricies sed dapibus urna mus in odio! Sed, pulvinar. Sagittis aenean in elit! Tortor velit porta urna magnis diam platea enim cum aliquet, hac dapibus! Ac ac sit est in platea placerat ac rhoncus! Proin diam integer in ac, scelerisque integer sed dignissim. Scelerisque auctor porttitor! Nisi? Amet mus adipiscing magnis cum? Auctor pellentesque lundium, ut habitasse magna ut, placerat vut porta? Rhoncus nec magnis, eu pulvinar.');
                ?>
            </div>
        </div>
	</div>

@stop