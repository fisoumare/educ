<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">

<title>{{Ets::get('nom')}}</title>

<!-- Bootstrap core CSS -->
<link href="<?php echo asset('assets/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('assets/bootstrap/css/font-awesome.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('assets/bootstrap/css/bootstrap-glyphicons.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('assets/bootstrap/css/datepicker.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('assets/bootstrap/css/bootstrap-fileupload.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('assets/css/style.css'); ?>" rel="stylesheet">


<script src="<?php echo asset('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo asset('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo asset('assets/js/jquery.flot.js'); ?>"></script>
<script src="<?php echo asset('assets/js/jquery.flot.pie.js'); ?>"></script>
<script src="<?php echo asset('assets/bootstrap/js/bootstrap-datepicker.js'); ?>"></script>
<script src="<?php echo asset('assets/bootstrap/js/bootstrap-fileupload.js'); ?>"></script>

<link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>