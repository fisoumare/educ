
</div>
</body>

<script type="text/javascript">
    $(document).ready(function(){
        /*
       $("table").tablecloth({
          theme: "default",
          condensed: true,
          striped: true,
          sortable: true,
          clean: true,
          cleanElements: "th td",
          customClass: "my-table"
        });*/
        
        $('hr').addClass('hr');
        $('.alert').css('color','#333333');
    });
</script>

</html>