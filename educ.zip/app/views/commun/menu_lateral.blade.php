<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title">Outils</h4>
    </div>
    <div class="panel-body">
    </div>
    <div class="list-group">
        <a class="list-group-item" href="http://localhost/guineequotidien/public/article/posts/all">
            Tous les articles »
        </a>
        <a class="list-group-item" href="http://localhost/guineequotidien/public/actualites/politique">
            Politique »
        </a>
        <a class="list-group-item" href="http://localhost/guineequotidien/public/actualites/sport">
            Sport »
        </a>
        <a class="list-group-item" href="http://localhost/guineequotidien/public/actualites/culture">
            Culture »
        </a>
        <a class="list-group-item" href="http://localhost/guineequotidien/public/actualites/economie">
            Economie »
        </a>
        <a class="list-group-item" href="http://localhost/guineequotidien/public/actualites/international">
            International »
        </a>
        <a class="list-group-item" href="http://localhost/guineequotidien/public/actualites/test">
            test »
        </a>
    </div>
</div>