<?php

class TestController extends BaseController {

    public function getIndex()
    {

    }
}