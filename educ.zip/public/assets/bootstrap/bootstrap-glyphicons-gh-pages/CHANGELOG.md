## 1.0.0

Port icons from latest development version of Bootstrap 3 into separate repository.
